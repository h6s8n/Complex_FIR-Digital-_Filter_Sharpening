b = firpm(15, [0.05 0.49]*2, [1 1],'hilbfilt');

