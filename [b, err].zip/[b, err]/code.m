b = cfirpm(18,[-0.5 -0.25 -0.2 0.35 0.4 0.5]*2,@lowpass);
fvtool(b,1,'OverlayedAnalysis','phase')
